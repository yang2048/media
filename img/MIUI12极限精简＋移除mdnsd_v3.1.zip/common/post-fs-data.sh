#!/system/bin/sh
#方法来自雄氏老方（取自旧梦模块内容）
Analysis=$(find /data/user/0/ -name "app_analytics")
echo "$Analysis"
rm -rf $Analysis
