#!/system/bin/sh
sleep 5

am kill mdnsd
killall -9 mdnsd

am kill mdnsd.rc
killall -9 mdnsd.rc

#冻结（感谢风雪大佬）
pm disable com.miui.analytics

if
pm disable com.miui.analytics
pm disable com.miui.systemAdSolution
then
sleep 1500
#方法来自雄氏老方（取自旧梦模块内容）
Analysis=$(find /data/user/0/ -name "app_analytics")
echo "$Analysis"
rm -rf $Analysis
sleep 3
fi