SKIPMOUNT=false PROPFILE=false POSTFSDATA=true LATESTARTSERVICE=true
#####################################################################################
MIUI="`getprop ro.miui.ui.version.name`"
ID="`grep_prop id $TMPDIR/module.prop`"
print_modname() {
    ui_print "###############################"
    ui_print "- 模块: $MODNAME "
    ui_print "- 模块ID: $ID "
    ui_print "- 模块作者: 奶皇Pro"
    ui_print "- 感谢指导: 阿巴酱"
    ui_print "- 你的设备: $MIUI"    
    ui_print "###############################"
}

on_install() {
    if [ $MIUI = "V12" ] ; then :
    elif [ $MIUI = "V125" ] ; then : 
    else
    echo "- 抱歉，当前MIUI版本不支持（已支持的版本：MIUI12/12.5）" 
    rm -rf $MODPATH
    rm -rf $TMPDIR
    exit 1
    fi
    ui_print " "
    ui_print "- 你的系统版本符合"
#####################################################################################

#不要修改到上面的内容，否则刷入失败！

#  ABajiang：
# ● 以下精简如果有你需要用到的功能，删除对应内容即可，看下面的注释。

REPLACE="
/system/app/XiaomiSimActivateService
/system/app/AnalyticsCore
/system/app/AutoRegistration
/system/app/BasicDreams
/system/app/BookmarkProvider
/system/app/Brevent
/system/app/CatchLog
/system/app/Cit
/system/app/CompanionDeviceManager
/system/app/FrequentPhrase
/system/app/goodix_sz
/system/app/greenguard
/system/app/HybridPlatform
/system/app/Joyose
/system/app/LiveWallpaperPicker
/system/app/mab
/system/app/MiuiBugReport
/system/app/MiuiWallpaper
/system/app/MSA
/system/app/PacProcessor
/system/app/SimAppDialog
/system/app/SimContact
/system/app/Stk
/system/app/TouchAssistant
/system/app/Traceur
/system/app/VoiceAssist
/system/app/VoiceTrigger
/system/app/WallpaperBackup
/system/app/YouDaoEngine
/system/priv-app/CallLogBackup
/system/priv-app/MiGameCenterSDKService
/system/priv-app/MusicFX
/system/priv-app/NewHome
/system/priv-app/ONS
/system/priv-app/QuickSearchBox
/system/priv-app/UserDictionaryProvider
/system/priv-app/ViPERFX
/system/data-app/com.standardar.service
/system/data-app/GameCenter
/system/data-app/MiLiveAssistant
/system/data-app/SmartTravel
/system/data-app/Userguide
/system/data-app/VipAccount
/system/data-app/VirtualSim
/system/data-app/XMPass
/system/product/app/aiasst_service
/system/product/app/PhotoTable
/system/product/app/talkback
/system/product/priv-app/EmergencyInfo
/system/product/priv-app/GmsCore
/system/priv-app/BuiltInPrintService
/system/app/ModemTestBox
/system/app/talkback
/system/app/MiuiDaemon
/system/app/Userguide
/system/app/PrintSpooler
/system/app/BuiltInPrintService
/system/priv-app/MiuiAod
"

ui_print "

# ● 注释如下：
# ✔ 新增：MIUI12.5系统打印服务 /system/priv-app/BuiltInPrintService
# ✔ 新增：乌龟rom包的蝰蛇音效（后台持续运行费电，故而关闭，如有需要请自行删除路径）/system/priv-app/ViPERFX
# 基本互动屏保（两个，无用功能，已被废除）/system/app/BasicDreams，/system/product/app/PhotoTable
# MODEM测试工具（官方维修人员专用）/system/app/ModemTestBox
# cit硬件功能检测（官方维修人员专用）/system/app/Cit
# 悬浮球/system/app/TouchAssistant
# 残疾人无障碍服务/system/app/talkback
# 天线服务/system/app/AntHalService
# 急救信息（无需用到且接口已被废除）/system/product/priv-app/EmergencyInfo
# 小米免费短信服务（大概已知是移动对移动发送短信可免费，实用性=0且特别耗电）/system/priv-app/MiRcs
# 小米互联通信服务（推送服务，没任何影响）/system/app/mi_connect_service
# 推送服务（两个，没任何影响）/system/app/WMService，/system/app/WAPPushManager
# 系统跟踪（无关痛痒的生成systrace报告，精简可提升流畅度）/system/app/Traceur
# 用户反馈/system/app/MiuiBugReport
# 服务与反馈/system/priv-app/MiService
# 用户信息收集/system/app/MiuiDaemon
# 用户手册/system/app/Userguide
# 用户字典/system/priv-app/UserDictionaryProvider
# 存储已屏蔽的号码（无任何影响）/system/priv-app/BlockedNumberProvider
# USIM卡应用（每次开机都提醒，没啥用处又占内存）/system/app/Stk
# SIM日志（无用）/system/app/SimAppDialog
# SIM联系人（现在谁还用sim卡存储联系人号码..）/system/app/SimContact
# 反馈bug时收集日志/system/app/CatchLog
# 广告组件（两个）/system/app/AnalyticsCore，/system/app/MSA
# 内容中心/system/priv-app/NewHome
# 快应用支持组件/system/app/HybridAccessory（快应用组件精简后，息屏状态下按指纹会等一秒钟左右才会出现指纹解锁图案开始解锁）
# 快应用服务框架（占后台的应用。如果还存在可以在应用商店卸载，需要用到再重装）/system/app/HybridPlatform
# 打印处理服务/system/app/PrintSpooler
# 系统打印服务/system/app/BuiltInPrintService
# Goodix指纹（出厂检测指纹用的，没任何影响）/system/app/goodix_sz
# 小米互传/system/priv-app/MiShare
# NFC服务/system/app/NQNfcNci
# 智能助理（负一屏）/system/priv-app/PersonalAssistant
# 搜索/system/priv-app/QuickSearchBox
# 小米智能卡/system/app/TSMClient
# 万象息屏/system/priv-app/MiuiAod
# AI虚拟助手/system/app/AiAsstVision
# 生活黄页/system/priv-app/YellowPage
# 投屏服务（三个）/system/priv-app/WfdService，/system/app/MiLinkService2，/system/app/MiPlayClient
"

echo "- Analytics"
if
pm disable com.miui.analytics
pm disable com.miui.systemAdSolution
then
echo "- 已冻结"
fi
Analysis=$(find /data/user/0/ -name "app_analytics")
echo "$Analysis"
if
rm -rf $Analysis
then : 
fi
}

—————————————————————————————————————————————

# ●温馨提醒：注意以下列出的千万不要精简!!否则可能卡米!!!
# SecurityCoreAdd 安全核心组件
# XiaomiServiceFramework 小米服务框架
# Browser MIUI浏览器
# MiSettings 设置
# MiuiSystemUI 系统UI
# miui 系统核心组件
# Updater 系统更新


































































































set_permissions() {
  set_perm_recursive  $MODPATH  0  0  0755  0644
  ui_print " "
  sleep 1
  ABajiang=$MODPATH/module.prop
  time0=$(date "+%Y-%m-%d %H:%M")
  echo "- 当前时间: $time0"
  echo "$time0" >> $ABajiang
  sleep 3
#Author of this module: ABajiang
#Here is the author's cool home page, if there is a problem with the use of modules can contact the author!
  coolapkTesting=`pm list package | grep -w 'com.coolapk.market'`
  if [[ "$coolapkTesting" != "" ]];then
  am start -d 'coolmarket://u/1132618' >/dev/null 2>&1
  fi
#Please do not modify this line of code, respect the author. Thank.
}